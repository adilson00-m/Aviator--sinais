
const TelegramBot = require('node-telegram-bot-api');
const WebSocket = require('ws');
const express = require('express');
const path = require('path');

// Substitua com seu token
const token = '123456789:ABCdefGHIjklMNOpqrSTUvwxYZ';
const canalId = '@nomedoseucanal'; // ou '-100xxxxxxxxxx'

const bot = new TelegramBot(token, { polling: true });

// Servidor Express + WebSocket
const app = express();
const server = app.listen(3000, () => console.log('Servidor rodando em http://localhost:3000'));
const wss = new WebSocket.Server({ server });

// Serve o frontend
app.use(express.static(path.join(__dirname, '../frontend')));

// Lista de conexões WebSocket
let clients = [];

wss.on('connection', ws => {
  clients.push(ws);
  ws.on('close', () => {
    clients = clients.filter(c => c !== ws);
  });
});

// Escuta mensagens do canal
bot.on('message', (msg) => {
  if (
    msg.chat.username === canalId.replace('@', '') ||
    msg.chat.id.toString() === canalId
  ) {
    const texto = `[${new Date().toLocaleTimeString()}] ${msg.text}`;
    console.log(texto);
    clients.forEach(ws => ws.send(texto));
  }
});
